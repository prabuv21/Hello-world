#!/usr/bin/env node

process.stdout.write('Hello World\n');
