main() {
  print('Hello, World!');
}
