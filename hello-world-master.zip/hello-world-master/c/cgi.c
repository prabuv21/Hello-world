#include <stdio.h>

main ()
{
   printf ("Content-type: text/html\n");
   printf ("\n");
   printf ("<html>\n");
   printf ("<head>\n");
   printf ("<title>Hello, world</title>\n");
   printf ("</head>\n");
   printf ("\n");
   printf ("<body>\n");
   printf ("<h1>Hello, world</h1>\n");
   printf ("</body>\n");
   printf ("</html>\n");
}
