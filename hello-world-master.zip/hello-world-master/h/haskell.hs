module Main where

main = putStrLn "Hello, World!"
