package main

import "fmt"

func main() {
  fmt.Printf("Hello, 世界\n")
}
