SELECT 'Hello World' as hello_message;
